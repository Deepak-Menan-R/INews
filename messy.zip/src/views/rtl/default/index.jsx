// Dashboard.jsx
import React from 'react';
import FeedbackForm from './components/FeedbackForm';

function Dashboard() {
  return (
    
      <div className="app-container">
        <FeedbackForm />
      </div>
    
  );
}

export default Dashboard;
