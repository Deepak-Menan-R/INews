export const tableColumnsTopCreators = [
  {
    Header: "Name",
    accessor: "name",
  }
  
];
